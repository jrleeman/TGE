##Python script to plot data from BME280 Atmospheric breakout board.
##
import matplotlib.pyplot as plt
import numpy as np
from numpy import genfromtxt
import os
import fnmatch
from os import listdir
from os.path import isfile, join

##Add YOUR path to where ever you store your data
##Format: [/Users/...data_directory/]
##Open array for list of files
mypath = str('[/Users/...data_directory/]')
file_list = []

##generate file list from CSV files in data directory
files = [f for f in listdir(mypath) if isfile(join(mypath, f))]
for file in files:
    if fnmatch.fnmatch(file,'*.csv'):
        file_list.append(file)

##check file list
print file_list

##Set sampling frequency
samp_int = 30.
samp_frq = 1/samp_int

##Control loop for user input. Use the stage number of the file you want to
##plot at the user input prompt. Otherwise it will throw an error and request
##you to re-input the desired stage.
while True:
    try:
        stage  = int(input('Stage:'))
        ##Use the name of your data file here!
        test = str('WS_data_%d.csv' %stage)
    except ValueError:
        continue
    if test in file_list:
        file = test
        break
    else:
        print 'File not found.\n'

##Load data into numpy array.
data = genfromtxt(file,delimiter = ',',skip_header = 1)

#Set variables into named one dimensional arrays
sample_num = data[:,0]                  #Sample number
temp = data[:,1]                        #Temperature (degrees C)
press = data[:,2]                       #Atmospheric pressure (kPa)
alt = data[:,3]                         #Altitude (m)
rlt_hm = data[:,4]                      #Relative humidity (%)
SM_1 = data[:,5]                        #Soil Moisture sensor 1
SM_2 = data[:,6]                        #Soil Moisture sensor 2
SM_3 = data[:,7]                        #Soil Moisture sensor 3

Maximum_SM = 900.

#Create time array from sample frequency and sample number
time = np.zeros([data.shape[0],])

#Calculate time
for i in range(0,time.size):
    time[i] = (sample_num[i]/samp_frq)/3600.

##Plots two sets of figures. Plot 1 has four pannels: Temp, pressure, Altitude,
##and relative humidity. Plot 2 has three pannels, one for each temperature
##sensor.
##################################Atmospheric data plot#########################
fig = plt.figure(figsize=(12,12))
ax = fig.add_subplot(2,2,1)
ax.plot(time[:],temp[:],label = 'Temperature $C$', linewidth = 2, c = 'k')
ax.set_ylim([np.min(temp)-2,np.max(temp)+2])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Temperature $^oC$',fontsize = 15)
ax.set_xlabel('Time $hr$',fontsize = 15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)
plt.title('Temperature', size = 20)

ax = fig.add_subplot(2,2,2)
ax.plot(time[:],press[:]/1000., label = 'Atmospheric pressure $kPa$', linewidth = 2, c = 'k')
ax.set_ylim([np.min(press/1000.)-1,np.max(press/1000.)+1])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Atmospheric pressure kPa',fontsize = 15)
ax.set_xlabel('Time $hr$', fontsize=15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.title('Pressure',size = 20)

ax = fig.add_subplot(2,2,3)
ax.plot(time[:],alt[:],label = 'Elevation $m$', linewidth = 2, c = 'k')
ax.set_ylim([np.min(alt)-5,np.max(alt)+5])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Elevation $m$',fontsize = 15)
ax.set_xlabel('Time $hr$', fontsize=15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)
plt.title('Elevation', size = 20)

ax = fig.add_subplot(2,2,4)
ax.plot(time[:],rlt_hm[:], label = 'Relative humidity %', linewidth = 2, c = 'k')
ax.set_ylim([np.min(rlt_hm)-20,100])
ax.set_xlim([0,np.max(time)])
ax.set_xlabel('Time $hr$', fontsize=15)
ax.set_ylabel('Relative humidity %',fontsize = 15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)
plt.title('Humidity',size = 20)

#Saves the plot as pdf.
plt.savefig(mypath+'/Plots/Atmospheric_data_%d.pdf' %stage)

plt.show()

##################################Soil moisture plot############################
fig = plt.figure(figsize=(10,10))
ax = fig.add_subplot(3,1,1)
ax.plot(time[:],(SM_1[:]/Maximum_SM)*100,label = 'Soil moisture sensor 1', linewidth = 2, c = 'k')
ax.set_ylim([0,100])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Soil Moisture',fontsize = 15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)
plt.title('Soil Moisture', size = 20)

ax = fig.add_subplot(3,1,2)
ax.plot(time[:],(SM_2[:]/Maximum_SM)*100, label = 'Soil moisture sensor 2', linewidth = 2, c = 'k')
ax.set_ylim([0,100])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Soil Moisture',fontsize = 15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)

ax = fig.add_subplot(3,1,3)
ax.plot(time[:],(SM_3[:]/Maximum_SM)*100,label = 'Soil moisture sensor 3', linewidth = 2, c = 'k')
ax.set_ylim([0,100])
ax.set_xlim([0,np.max(time)])
ax.set_ylabel('Soil Moisture',fontsize = 15)
ax.set_xlabel('Time $hr$', fontsize=15)
ax.tick_params(axis='both', which='major', labelsize=14)
plt.legend(loc='upper left', fontsize = 14)

#Saves the plot as pdf.
plt.savefig(mypath+'/Plots/Soil_moisture_%d.pdf' %stage)

plt.show()
